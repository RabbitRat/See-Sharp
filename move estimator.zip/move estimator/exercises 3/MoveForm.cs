﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercises_3
{
    public partial class MoveForm : Form
    {
        public MoveForm()
        {
            InitializeComponent();
        }

        private void estimateButton_Click(object sender, EventArgs e)
        {
            double hours, miles, estimate;
            const double BASE = 200;

            const double HOURLY = 150;
            const double RATE_PER_MILE = 2;

            //convert string to double
            hours = double.Parse(hourBox.Text);
            //convert string to double
            miles = Convert.ToDouble(mileBox.Text);

            estimate = BASE + hours * HOURLY + miles * RATE_PER_MILE;

            //print out output label
            outputLabel.Text = String.Format("For a move taking {0} hours and going {1} miles, " +
                "the estimated cost is {2:C}.", hours, miles, estimate);



        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            hourBox.Clear();
            mileBox.Clear();
            outputLabel.Text = "";
            hourBox.Focus();
        }
    }
}
