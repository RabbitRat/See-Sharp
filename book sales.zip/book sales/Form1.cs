﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace book_sales
{
    public partial class BookSalesForm : Form
    {
        public BookSalesForm()
        {
            InitializeComponent();
        }

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void orderButton_Click(object sender, EventArgs e)
        {
            double unitPrice, currentSale;
            int quantitySold;
            Booksale mySale;

            double.TryParse(priceTextBox.Text, out unitPrice);
         
                
            quantitySold = int.Parse(quantityTextBox.Text);
            mySale = new Booksale(titleTextBox.Text, unitPrice, quantitySold);
            currentSale = mySale.ExtendedPrice();

            if (studentCheckBox.Checked)
            {
                currentSale = currentSale - currentSale * 0.1;
            }

            currentOrderLabel.Text = String.Format("This order is {0:C} for {1} books.", currentSale, quantitySold);
        }

        private void studentCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (studentCheckBox.Checked)
            {
                
            }
        }
    }
}
