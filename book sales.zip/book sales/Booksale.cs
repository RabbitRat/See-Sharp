﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace book_sales
{
    class Booksale
    {
        private string bookTitle;
        private double bookPrice;
        private int saleQuantity;

        public Booksale() { }

        public Booksale(string title, double price, int quantity)
        {
            bookTitle = title;
            bookPrice = price;
            saleQuantity = quantity;

        }

        public string Title
        {
            set
            {
                bookTitle = value;
            }
            get
            {
                return bookTitle;
            }
        }

        public double Price
        {
            set
            {
                bookPrice = value;
            }
        }

        public int Quantity
        {
            set
            {
                saleQuantity = value;
            }
        }

        public double ExtendedPrice()
        {
            return bookPrice * saleQuantity;
        }
    }
}
