﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InchesToCentimeters
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            string input;
            double inches, centimeters;
            const double CENTIMETERS_IN_INCH = 2.54;
            
            //Prompt the user's input
            Console.Write("Enter value in Inch: ");
            input = Console.ReadLine();

            //Convert to double data type
            inches = double.Parse(input);

            //Calculation
            centimeters = inches* CENTIMETERS_IN_INCH;

            //Print out result
            Console.WriteLine();
            Console.WriteLine("{0} inches is {1} centimeters.", inches, centimeters);


            Console.ReadKey();
        }
    }
}
