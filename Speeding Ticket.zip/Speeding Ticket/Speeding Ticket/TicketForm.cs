﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Speeding_Ticket
{
    public partial class SpeedingTicket : Form
    {
        public SpeedingTicket()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void clearbutton_Click(object sender, EventArgs e)
        {
            stnumber.Clear();
            stname.Clear();
            yearbox.Clear();
            speedlimit.Clear();
            drivingspeed.Clear();
            stnumber.Focus();
        }

        private void displaybutton_Click(object sender, EventArgs e)
        {
            //declare variable
            const double BASE = 75;
            const double COST_PER_5_OVER = 87.50;

            int speedLimit, drivingSpeed, milesOverSpeedLimit; 
            string year, ticketMessage, classificationName;

            double fine;

            //assign text box to variable
            drivingSpeed = int.Parse(drivingspeed.Text);
            speedLimit = int.Parse(speedlimit.Text);

            milesOverSpeedLimit = drivingSpeed - speedLimit;

            //Calculation
            fine = BASE + COST_PER_5_OVER * (milesOverSpeedLimit/5);

            //Extra fined
            year = yearbox.Text;

            if (year == "5")
                if (milesOverSpeedLimit < 20)
                    fine += 50;
                else
                    fine += 200;
            else if ((year == "1") && (milesOverSpeedLimit < 20))
                fine -= 50;
            else
                if (milesOverSpeedLimit >= 20)
                fine += 100;

            //clarify student class
            switch(year)
            {
                case "1":
                    classificationName = "Freshman";
                    break;
                case "2":
                    classificationName = "Sophomore";
                    break;
                case "3":
                    classificationName = "Pre-Junior";
                    break;
                case "4":
                    classificationName = "Junior";
                    break;
                case "5":
                    classificationName = "Senior";
                    break;
                default:
                    classificationName = "Unspecified";
                    break;
            }

            //display message
            ticketMessage = "\tSpeeding Ticket"
                + "\nStudent Number: " + stnumber.Text
                + "\nStudent Name: " + stname.Text
                + "\nClassification: " + classificationName
                + "\nSpeed Limit: " + speedlimit.Text
                + "\nReported Speed: " + fine.ToString("C"); 

            MessageBox.Show(ticketMessage);



        }

        private void exitbutton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
