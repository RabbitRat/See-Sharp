﻿
namespace Speeding_Ticket
{
    partial class SpeedingTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.stnumber = new System.Windows.Forms.TextBox();
            this.stname = new System.Windows.Forms.TextBox();
            this.yearbox = new System.Windows.Forms.TextBox();
            this.speedlimit = new System.Windows.Forms.TextBox();
            this.drivingspeed = new System.Windows.Forms.TextBox();
            this.displaybutton = new System.Windows.Forms.Button();
            this.clearbutton = new System.Windows.Forms.Button();
            this.exitbutton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(265, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(325, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "On-Campus Speeding Ticket";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 95);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Student Numer:";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(376, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(143, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Student Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 182);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(668, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Year in school (1-Freshman, 2-Sophomore, 3-Prejunior, 4-Junior, 5-Senior):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 267);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Speed Limit:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(378, 267);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(141, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Driving Speed:";
            // 
            // stnumber
            // 
            this.stnumber.Location = new System.Drawing.Point(179, 92);
            this.stnumber.Name = "stnumber";
            this.stnumber.Size = new System.Drawing.Size(165, 30);
            this.stnumber.TabIndex = 6;
            // 
            // stname
            // 
            this.stname.Location = new System.Drawing.Point(574, 92);
            this.stname.Name = "stname";
            this.stname.Size = new System.Drawing.Size(256, 30);
            this.stname.TabIndex = 7;
            // 
            // yearbox
            // 
            this.yearbox.Location = new System.Drawing.Point(726, 182);
            this.yearbox.Name = "yearbox";
            this.yearbox.Size = new System.Drawing.Size(104, 30);
            this.yearbox.TabIndex = 8;
            // 
            // speedlimit
            // 
            this.speedlimit.Location = new System.Drawing.Point(179, 264);
            this.speedlimit.Name = "speedlimit";
            this.speedlimit.Size = new System.Drawing.Size(165, 30);
            this.speedlimit.TabIndex = 9;
            // 
            // drivingspeed
            // 
            this.drivingspeed.Location = new System.Drawing.Point(574, 262);
            this.drivingspeed.Name = "drivingspeed";
            this.drivingspeed.Size = new System.Drawing.Size(256, 30);
            this.drivingspeed.TabIndex = 10;
            // 
            // displaybutton
            // 
            this.displaybutton.Location = new System.Drawing.Point(57, 338);
            this.displaybutton.Name = "displaybutton";
            this.displaybutton.Size = new System.Drawing.Size(213, 43);
            this.displaybutton.TabIndex = 11;
            this.displaybutton.Text = "&Display Ticket";
            this.displaybutton.UseVisualStyleBackColor = true;
            this.displaybutton.Click += new System.EventHandler(this.displaybutton_Click);
            // 
            // clearbutton
            // 
            this.clearbutton.Location = new System.Drawing.Point(317, 338);
            this.clearbutton.Name = "clearbutton";
            this.clearbutton.Size = new System.Drawing.Size(213, 43);
            this.clearbutton.TabIndex = 12;
            this.clearbutton.Text = "Clear Ticket";
            this.clearbutton.UseVisualStyleBackColor = true;
            this.clearbutton.Click += new System.EventHandler(this.clearbutton_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.Location = new System.Drawing.Point(574, 338);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(213, 43);
            this.exitbutton.TabIndex = 13;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // SpeedingTicket
            // 
            this.AcceptButton = this.displaybutton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(862, 420);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.clearbutton);
            this.Controls.Add(this.displaybutton);
            this.Controls.Add(this.drivingspeed);
            this.Controls.Add(this.speedlimit);
            this.Controls.Add(this.yearbox);
            this.Controls.Add(this.stname);
            this.Controls.Add(this.stnumber);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SpeedingTicket";
            this.Text = "Speeding Ticket";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox stnumber;
        private System.Windows.Forms.TextBox stname;
        private System.Windows.Forms.TextBox yearbox;
        private System.Windows.Forms.TextBox speedlimit;
        private System.Windows.Forms.TextBox drivingspeed;
        private System.Windows.Forms.Button displaybutton;
        private System.Windows.Forms.Button clearbutton;
        private System.Windows.Forms.Button exitbutton;
    }
}

