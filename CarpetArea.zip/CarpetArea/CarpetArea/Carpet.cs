﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarpetArea
{
    class Carpet
    {
        public const string MOTTO = "Our carpets are quality - made";
        private int length;
        private int width;
        private int area;

        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public int Area
        {
            get { return width * length; }
        }

        public double CalcArea()
        {
            area = Length * Width;
            return area;
        }
    }
}
