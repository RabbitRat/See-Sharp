﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarpetArea
{
    class Program
    {
        static void Main(string[] args)
        {
            Carpet aRug = new Carpet();

            int dimW, dimL;
            double totalArea = 0;
            string response = "Y";

            while (response == "Y" | response == "y")
            {
                Console.Write("Enter room width: ");
                dimW = int.Parse(Console.ReadLine());

                Console.Write("Enter room length: ");
                dimL = int.Parse(Console.ReadLine());

                aRug.Width = dimW;
                aRug.Length = dimL;

                Console.Write("The {0} x {1} carpet has an area of {2}", aRug.Width, aRug.Length, aRug.Area);

                totalArea += aRug.Area;


                //Since we can have multiple rooms -> using loop

                Console.Write("\nDo you have another piece? (Y or N) ");
                response = Console.ReadLine();
            }

            Console.WriteLine("The total area is {0}", totalArea);

            Console.WriteLine(Carpet.MOTTO);
            Console.ReadKey();

        }
    }
}
