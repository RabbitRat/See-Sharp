﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c5Exercises
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            double dinnerPrice = 10, tipRate, tip;
            const double LOWRATE = 0.10, MAXRATE = 0.25, RATESTEP = 0.05;
            const double MAXPRICE = 100, PRICESTEP = 10;

            Console.Write("   Price");

            //ask input from the user


            //outer loop
            for (tipRate = LOWRATE; tipRate <= MAXRATE; tipRate += RATESTEP)
                Console.Write("{0,8}", tipRate.ToString("F"));   //8 spaces
            Console.WriteLine();
            Console.WriteLine("----------------------------------------");  //40 dashes: 8*5=40

            //outer loop
            /*        while (dinnerPrice <= MAXPRICE) */
            for (; dinnerPrice <= MAXPRICE; dinnerPrice += PRICESTEP)
            {
                Console.Write("{0,8}", dinnerPrice.ToString("C")); //print out the original price

                /*tipRate = LOWRATE;*/



                //inner loop
                /*while (tipRate <= MAXRATE)*/
                for (tipRate = LOWRATE; tipRate <= MAXRATE; tipRate += RATESTEP)
                {

                    tip = dinnerPrice * tipRate;
                    Console.Write("{0,8}", tip.ToString("C")); //print out the tip
                    /*tipRate += RATESTEP;*/
                }

                /*dinnerPrice += PRICESTEP;*/
                Console.WriteLine();
            }
            Console.ReadLine();
            
        }
    }
}
