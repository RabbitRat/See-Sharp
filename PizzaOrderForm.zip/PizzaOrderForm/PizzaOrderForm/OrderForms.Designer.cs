﻿
namespace PizzaOrderForm
{
    partial class OrderForms
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrderForms));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.CBOnions = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CBGreenPepper = new System.Windows.Forms.CheckBox();
            this.CBPepperoni = new System.Windows.Forms.CheckBox();
            this.CBSausage = new System.Windows.Forms.CheckBox();
            this.label5 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.outputLabel = new System.Windows.Forms.Label();
            this.RBPickup = new System.Windows.Forms.RadioButton();
            this.RBDelivery = new System.Windows.Forms.RadioButton();
            this.RBDinein = new System.Windows.Forms.RadioButton();
            this.LBSize = new System.Windows.Forms.ListBox();
            this.Calendar = new System.Windows.Forms.MonthCalendar();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.orderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.NewOrderMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.DisplayOrderMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ExitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(166, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(263, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pizza Order Form";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(40, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(195, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "Select toppings";
            // 
            // CBOnions
            // 
            this.CBOnions.AutoSize = true;
            this.CBOnions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBOnions.Location = new System.Drawing.Point(45, 160);
            this.CBOnions.Name = "CBOnions";
            this.CBOnions.Size = new System.Drawing.Size(97, 29);
            this.CBOnions.TabIndex = 2;
            this.CBOnions.Text = "Onions";
            this.CBOnions.UseVisualStyleBackColor = true;
            this.CBOnions.CheckedChanged += new System.EventHandler(this.CBOnions_CheckedChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(311, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(181, 29);
            this.label3.TabIndex = 3;
            this.label3.Text = "Dining options";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(568, 111);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(121, 29);
            this.label4.TabIndex = 4;
            this.label4.Text = "For Date:";
            // 
            // CBGreenPepper
            // 
            this.CBGreenPepper.AutoSize = true;
            this.CBGreenPepper.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBGreenPepper.Location = new System.Drawing.Point(45, 195);
            this.CBGreenPepper.Name = "CBGreenPepper";
            this.CBGreenPepper.Size = new System.Drawing.Size(156, 29);
            this.CBGreenPepper.TabIndex = 5;
            this.CBGreenPepper.Text = "Green Pepper";
            this.CBGreenPepper.UseVisualStyleBackColor = true;
            this.CBGreenPepper.CheckedChanged += new System.EventHandler(this.CBGreenPepper_CheckedChanged);
            // 
            // CBPepperoni
            // 
            this.CBPepperoni.AutoSize = true;
            this.CBPepperoni.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBPepperoni.Location = new System.Drawing.Point(45, 230);
            this.CBPepperoni.Name = "CBPepperoni";
            this.CBPepperoni.Size = new System.Drawing.Size(123, 29);
            this.CBPepperoni.TabIndex = 6;
            this.CBPepperoni.Text = "Pepperoni";
            this.CBPepperoni.UseVisualStyleBackColor = true;
            this.CBPepperoni.CheckedChanged += new System.EventHandler(this.CBPepperoni_CheckedChanged);
            // 
            // CBSausage
            // 
            this.CBSausage.AutoSize = true;
            this.CBSausage.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CBSausage.Location = new System.Drawing.Point(45, 265);
            this.CBSausage.Name = "CBSausage";
            this.CBSausage.Size = new System.Drawing.Size(113, 29);
            this.CBSausage.TabIndex = 7;
            this.CBSausage.Text = "Sausage";
            this.CBSausage.UseVisualStyleBackColor = true;
            this.CBSausage.CheckedChanged += new System.EventHandler(this.CBSausage_CheckedChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(40, 332);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(71, 29);
            this.label5.TabIndex = 8;
            this.label5.Text = "Size:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(463, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(87, 84);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 9;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // outputLabel
            // 
            this.outputLabel.AutoSize = true;
            this.outputLabel.Location = new System.Drawing.Point(265, 391);
            this.outputLabel.Name = "outputLabel";
            this.outputLabel.Size = new System.Drawing.Size(92, 29);
            this.outputLabel.TabIndex = 10;
            this.outputLabel.Text = "Total is";
            // 
            // RBPickup
            // 
            this.RBPickup.AutoSize = true;
            this.RBPickup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBPickup.Location = new System.Drawing.Point(322, 160);
            this.RBPickup.Name = "RBPickup";
            this.RBPickup.Size = new System.Drawing.Size(97, 29);
            this.RBPickup.TabIndex = 11;
            this.RBPickup.TabStop = true;
            this.RBPickup.Text = "Pick up";
            this.RBPickup.UseVisualStyleBackColor = true;
            this.RBPickup.CheckedChanged += new System.EventHandler(this.RBPickup_CheckedChanged);
            // 
            // RBDelivery
            // 
            this.RBDelivery.AutoSize = true;
            this.RBDelivery.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBDelivery.Location = new System.Drawing.Point(322, 202);
            this.RBDelivery.Name = "RBDelivery";
            this.RBDelivery.Size = new System.Drawing.Size(103, 29);
            this.RBDelivery.TabIndex = 12;
            this.RBDelivery.TabStop = true;
            this.RBDelivery.Text = "Delivery";
            this.RBDelivery.UseVisualStyleBackColor = true;
            this.RBDelivery.CheckedChanged += new System.EventHandler(this.RBDelivery_CheckedChanged);
            // 
            // RBDinein
            // 
            this.RBDinein.AutoSize = true;
            this.RBDinein.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RBDinein.Location = new System.Drawing.Point(322, 242);
            this.RBDinein.Name = "RBDinein";
            this.RBDinein.Size = new System.Drawing.Size(93, 29);
            this.RBDinein.TabIndex = 13;
            this.RBDinein.TabStop = true;
            this.RBDinein.Text = "Dine in";
            this.RBDinein.UseVisualStyleBackColor = true;
            this.RBDinein.CheckedChanged += new System.EventHandler(this.RBDinein_CheckedChanged);
            // 
            // LBSize
            // 
            this.LBSize.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBSize.FormattingEnabled = true;
            this.LBSize.ItemHeight = 25;
            this.LBSize.Items.AddRange(new object[] {
            "Small",
            "Medium",
            "Large"});
            this.LBSize.Location = new System.Drawing.Point(38, 377);
            this.LBSize.Name = "LBSize";
            this.LBSize.Size = new System.Drawing.Size(173, 79);
            this.LBSize.TabIndex = 14;
            this.LBSize.SelectedIndexChanged += new System.EventHandler(this.LBSize_SelectedIndexChanged);
            // 
            // Calendar
            // 
            this.Calendar.Location = new System.Drawing.Point(520, 160);
            this.Calendar.Name = "Calendar";
            this.Calendar.TabIndex = 15;
            this.Calendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.Calendar_DateChanged);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.orderToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(873, 28);
            this.menuStrip1.TabIndex = 16;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // orderToolStripMenuItem
            // 
            this.orderToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.NewOrderMenuItem,
            this.DisplayOrderMenuItem,
            this.ExitMenuItem});
            this.orderToolStripMenuItem.Name = "orderToolStripMenuItem";
            this.orderToolStripMenuItem.Size = new System.Drawing.Size(61, 24);
            this.orderToolStripMenuItem.Text = "Order";
            // 
            // NewOrderMenuItem
            // 
            this.NewOrderMenuItem.Name = "NewOrderMenuItem";
            this.NewOrderMenuItem.Size = new System.Drawing.Size(224, 26);
            this.NewOrderMenuItem.Text = "New";
            this.NewOrderMenuItem.Click += new System.EventHandler(this.NewOrderMenuItem_Click);
            // 
            // DisplayOrderMenuItem
            // 
            this.DisplayOrderMenuItem.Name = "DisplayOrderMenuItem";
            this.DisplayOrderMenuItem.Size = new System.Drawing.Size(224, 26);
            this.DisplayOrderMenuItem.Text = "Display";
            this.DisplayOrderMenuItem.Click += new System.EventHandler(this.DisplayOrderMenuItem_Click);
            // 
            // ExitMenuItem
            // 
            this.ExitMenuItem.Name = "ExitMenuItem";
            this.ExitMenuItem.Size = new System.Drawing.Size(224, 26);
            this.ExitMenuItem.Text = "Exit";
            this.ExitMenuItem.Click += new System.EventHandler(this.ExitMenuItem_Click);
            // 
            // OrderForms
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(873, 513);
            this.Controls.Add(this.Calendar);
            this.Controls.Add(this.LBSize);
            this.Controls.Add(this.RBDinein);
            this.Controls.Add(this.RBDelivery);
            this.Controls.Add(this.RBPickup);
            this.Controls.Add(this.outputLabel);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.CBSausage);
            this.Controls.Add(this.CBPepperoni);
            this.Controls.Add(this.CBGreenPepper);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.CBOnions);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "OrderForms";
            this.Text = "Pizza Order Form";
            this.Load += new System.EventHandler(this.OrderForms_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox CBOnions;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.CheckBox CBGreenPepper;
        private System.Windows.Forms.CheckBox CBPepperoni;
        private System.Windows.Forms.CheckBox CBSausage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label outputLabel;
        private System.Windows.Forms.RadioButton RBPickup;
        private System.Windows.Forms.RadioButton RBDelivery;
        private System.Windows.Forms.RadioButton RBDinein;
        private System.Windows.Forms.ListBox LBSize;
        private System.Windows.Forms.MonthCalendar Calendar;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem orderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem NewOrderMenuItem;
        private System.Windows.Forms.ToolStripMenuItem DisplayOrderMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ExitMenuItem;
    }
}

