﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PizzaOrderForm
{
    public partial class OrderForms : Form
    {
        //declare constant variable
        private const double BASE_PRICE = 12.00, TOPPING_PRICE = 1.25;
        private double price = BASE_PRICE;
        private const double SHIPPINGFEE = 2.00;
        private string SHIPPINGDATE;

        public OrderForms()
        {
            InitializeComponent();
        }

        private void OrderForms_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void CBGreenPepper_CheckedChanged(object sender, EventArgs e)
        {
            if (CBGreenPepper.Checked == true)
            {
                price += TOPPING_PRICE;
            }
            else
            {
                price -= TOPPING_PRICE;
            }
            outputLabel.Text = "Total is " + price.ToString("C");
        }

        private void CBPepperoni_CheckedChanged(object sender, EventArgs e)
        {
            if (CBPepperoni.Checked)
                price += TOPPING_PRICE;
            else
                price -= TOPPING_PRICE;

            outputLabel.Text = "Total is " + price.ToString("C");
        }

        private void CBSausage_CheckedChanged(object sender, EventArgs e)
        {
            if (CBSausage.Checked)
                price += TOPPING_PRICE;
            else
                price -= TOPPING_PRICE;

            outputLabel.Text = "Total is " + price.ToString("C");
        }

        private void RBPickup_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBDinein_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void RBDelivery_CheckedChanged(object sender, EventArgs e)
        {
            if (RBDelivery.Checked)
                price += SHIPPINGFEE;
            else
                price -= SHIPPINGFEE;

            outputLabel.Text = "Total is: " + price.ToString("C");
        }

        private void LBSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (LBSize.SelectedIndex)
            {
                case 0:
                    price = BASE_PRICE * 0.5;
                    break;
                case 1:
                    price = BASE_PRICE;
                    break;
                case 2:
                    price = BASE_PRICE * 1.2;
                    break;
                default:
                    price = BASE_PRICE;
                    break;
            }
            
            if (CBOnions.Checked)
                price += TOPPING_PRICE;
            if (CBGreenPepper.Checked)
                price += TOPPING_PRICE;
            if (CBPepperoni.Checked)
                price += TOPPING_PRICE;
            if (CBSausage.Checked)
                price += TOPPING_PRICE;

            outputLabel.Text = "Total is: " + price.ToString("C");


        }

        private void Calendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            SHIPPINGDATE = Calendar.SelectionStart.ToLongDateString();
            outputLabel.Text = "Total is: " + price.ToString("C") + "\nThe shipping date is: " + SHIPPINGDATE;
        }

        private void NewOrderMenuItem_Click(object sender, EventArgs e)
        {
            CBOnions.Checked = false; //not selected
            CBGreenPepper.Checked = false; //not selected
            CBPepperoni.Checked = false; //not selected
            CBSausage.Checked = false; //not selected

            //remove selected radio button
            RBPickup.Checked = false;
            RBDelivery.Checked = false;
            RBDinein.Checked = false;

            //remove size selected
            LBSize.SelectedIndex = -1;

            //set calendar default
            Calendar.SelectionStart = DateTime.Today;
            Calendar.SelectionEnd = DateTime.Today;

        }

        private void DisplayOrderMenuItem_Click(object sender, EventArgs e)
        {
            //pop-up message showing summary order
            string orderMessage;
            orderMessage = LBSize.SelectedItem.ToString() +
                " pizza, at " + price.ToString("C") +
                " ordered for " + SHIPPINGDATE +
                "\nwith topping ";
            if (CBGreenPepper.Checked)
                orderMessage += "Green Pepper";

            MessageBox.Show(orderMessage, "Order");
        }

        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CBOnions_CheckedChanged(object sender, EventArgs e)
        {
            if (CBOnions.Checked)
                price += TOPPING_PRICE;
            else
                price -= TOPPING_PRICE;

            outputLabel.Text = "Total is " + price.ToString("C");
        }
    }
}
