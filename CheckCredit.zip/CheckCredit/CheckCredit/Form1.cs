﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CheckCredit
{
    public partial class CheckCredit : Form
    {
        public CheckCredit()
        {
            InitializeComponent();
        }

        private void enterbutton_Click(object sender, EventArgs e)
        {
            int price;
            const int CREDIT_LIMIT = 8000;

            price = Convert.ToInt32(pricebox.Text);

            if (price > CREDIT_LIMIT)
                output.Text = "You have exceeded the credit limit of 8000";
            else
                output.Text = "Approved";
        }

    }
}
