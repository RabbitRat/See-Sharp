﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Movie_Discount
{
    public partial class MovieDiscount : Form
    {
        public MovieDiscount()
        {
            InitializeComponent();
        }

        private void discountbutton_Click(object sender, EventArgs e)
        {
            int age;
            char rating;

            const int CHILD_AGE = 11;
            const int SENIOR_AGE = 65;

            age = int.Parse(agebox.Text);  //convert string to int
            rating = Convert.ToChar(ratingbox.Text);

            if ((age < CHILD_AGE) | (age > SENIOR_AGE) && (rating == 'G' | rating == 'g'))
                outputtext.Text = "\nDiscount Applies"; //backlash n is insert new line
            else
                outputtext.Text = "\nFull price";
        }
    }
}
