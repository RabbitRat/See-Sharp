﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdmissionModularized
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputString;
            double gpa;
            double AdmissionTestScore;

            Console.Write("Enter your high school GPA: ");
            inputString = Console.ReadLine();                              //gpa=Convert.ToDouble(Console.ReadLine())

            /*while (double.TryParse(inputString, out gpa) == false)
            {
                Console.Write("Please enter GPA again: ");
                inputString = Console.ReadLine();
            }*/

            CallTryParse(inputString, out gpa);
            
            /*gpa = Convert.ToDouble(inputString);*/

            Console.Write("Enter your admission test score: ");
            inputString = Console.ReadLine();

            /*while (int.TryParse(inputString, out AdmissionTestScore) == false)
            {
                Console.Write("Please enter test score again: ");
                inputString = Console.ReadLine();
            }*/
            CallTryParse(inputString, out AdmissionTestScore);

            /*AdmissionTestScore = Convert.ToInt32(inputString);*/

            Console.WriteLine("\nThe recommendation is: " + AgreeOrReject(gpa, AdmissionTestScore));
            Console.ReadKey();
        }


        private static string AgreeOrReject(double GPA, double ATS)
        {
            const double minGPA = 3.0;
            const int ATS1 = 60, ATS2 = 80;
            string verdict;

            if ((GPA >= minGPA) && (ATS >= ATS1) || (GPA < minGPA) && (ATS >= ATS2))
                verdict = "Accept";
            else
                verdict = "Reject";

            return verdict;
        }

        private static void CallTryParse (string input, out double numberdata)
        {
            bool Validity = double.TryParse(input, out numberdata);
            while (Validity == false)
            {
                Console.Write("Please enter valid input: ");
                input = Console.ReadLine();
            }

        }

     }
}
