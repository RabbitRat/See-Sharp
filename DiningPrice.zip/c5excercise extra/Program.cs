﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace c5excercise_extra
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare variables
            string diningpriceAsString, inputString, TipPercentAsString, TotalPriceAsString;
            double diningPrice, input, TipPercent, Total, TotalPrice, Price;
            const double QUIT = 0;
            
            
            //ask users' input
            Console.Write("Enter your dining price>> ");
            diningpriceAsString = Console.ReadLine();
            diningPrice = Convert.ToDouble(diningpriceAsString);

            Console.Write("Press 1 to enter tip percent>> "
                            + "\nPress 2 to enter total price including your tip>> ");

            inputString = Console.ReadLine();
            input = Convert.ToDouble(inputString);

            //if user press 1 
            if (input == 1)
            {

                Console.Write("\n" + "\nWhat is your desired tip percent in decimal>> ");
                TipPercentAsString = Console.ReadLine();
                TipPercent = Convert.ToDouble(TipPercentAsString);

                //loop if user enter desired tip percent
                while (TipPercent != QUIT)
                {
                    Total = diningPrice + diningPrice * TipPercent;
                    Console.WriteLine("You will pay {0}", Total.ToString("C")
                                        + "\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + "\nPress 0 to exit"
                                        + "\nOr enter your desired tip percent>> ");

                    TipPercentAsString = Console.ReadLine();
                    TipPercent = Convert.ToDouble(TipPercentAsString);
                }

            }

            //if user press 2
            if (input == 2)
            {
                Console.Write("\n" + "\nWhat is your total price including your tip>> ");
                TotalPriceAsString = Console.ReadLine();
                TotalPrice = Convert.ToDouble(TotalPriceAsString);

                //loop if user enter the total price
                while (TotalPrice != QUIT)
                {
                    Price = (TotalPrice / diningPrice) - 1;
                    Console.Write("Your tip percent is {0}", Price.ToString("P")
                                       + "\n>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>" + "\nPress 0 to exit"
                                       + "\nOr enter your total price>> ");
                    TotalPriceAsString = Console.ReadLine();
                    TotalPrice = Convert.ToDouble(TotalPriceAsString);
                }
            }
        }
    }
}
