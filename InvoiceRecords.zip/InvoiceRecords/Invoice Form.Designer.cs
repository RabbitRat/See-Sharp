﻿
namespace InvoiceRecords
{
    partial class InvoiceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.InvoiceNum = new System.Windows.Forms.TextBox();
            this.NameBox = new System.Windows.Forms.TextBox();
            this.AmountBox = new System.Windows.Forms.TextBox();
            this.NextButton = new System.Windows.Forms.Button();
            this.InsertButton = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewExistingInvoicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenViewMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.FinishViewMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.enterNewInvoicesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenEnterMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveInvoiceMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.CloseFormMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.OpenInvoiceFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.SaveInvoiceFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(134, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Invoice records";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(51, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(154, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Invoice Number:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(51, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(70, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(51, 255);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(86, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Amount:";
            // 
            // InvoiceNum
            // 
            this.InvoiceNum.Location = new System.Drawing.Point(236, 130);
            this.InvoiceNum.Name = "InvoiceNum";
            this.InvoiceNum.Size = new System.Drawing.Size(119, 30);
            this.InvoiceNum.TabIndex = 4;
            this.InvoiceNum.TextChanged += new System.EventHandler(this.InvoiceNum_TextChanged);
            // 
            // NameBox
            // 
            this.NameBox.Location = new System.Drawing.Point(236, 194);
            this.NameBox.Name = "NameBox";
            this.NameBox.Size = new System.Drawing.Size(119, 30);
            this.NameBox.TabIndex = 5;
            // 
            // AmountBox
            // 
            this.AmountBox.Location = new System.Drawing.Point(236, 255);
            this.AmountBox.Name = "AmountBox";
            this.AmountBox.Size = new System.Drawing.Size(119, 30);
            this.AmountBox.TabIndex = 6;
            // 
            // NextButton
            // 
            this.NextButton.Location = new System.Drawing.Point(56, 328);
            this.NextButton.Name = "NextButton";
            this.NextButton.Size = new System.Drawing.Size(149, 34);
            this.NextButton.TabIndex = 7;
            this.NextButton.Text = "View next";
            this.NextButton.UseVisualStyleBackColor = true;
            this.NextButton.Click += new System.EventHandler(this.NextButton_Click);
            // 
            // InsertButton
            // 
            this.InsertButton.Location = new System.Drawing.Point(211, 328);
            this.InsertButton.Name = "InsertButton";
            this.InsertButton.Size = new System.Drawing.Size(144, 34);
            this.InsertButton.TabIndex = 8;
            this.InsertButton.Text = "Enter Record";
            this.InsertButton.UseVisualStyleBackColor = true;
            this.InsertButton.Click += new System.EventHandler(this.InsertButton_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewExistingInvoicesToolStripMenuItem,
            this.enterNewInvoicesToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(427, 28);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // viewExistingInvoicesToolStripMenuItem
            // 
            this.viewExistingInvoicesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenViewMenuItem,
            this.FinishViewMenuItem});
            this.viewExistingInvoicesToolStripMenuItem.Name = "viewExistingInvoicesToolStripMenuItem";
            this.viewExistingInvoicesToolStripMenuItem.Size = new System.Drawing.Size(167, 24);
            this.viewExistingInvoicesToolStripMenuItem.Text = "View existing invoices";
            // 
            // OpenViewMenuItem
            // 
            this.OpenViewMenuItem.Name = "OpenViewMenuItem";
            this.OpenViewMenuItem.Size = new System.Drawing.Size(224, 26);
            this.OpenViewMenuItem.Text = "Open an invoice file";
            this.OpenViewMenuItem.Click += new System.EventHandler(this.OpenViewMenuItem_Click);
            // 
            // FinishViewMenuItem
            // 
            this.FinishViewMenuItem.Name = "FinishViewMenuItem";
            this.FinishViewMenuItem.Size = new System.Drawing.Size(224, 26);
            this.FinishViewMenuItem.Text = "Finish viewing";
            this.FinishViewMenuItem.Click += new System.EventHandler(this.FinishViewMenuItem_Click);
            // 
            // enterNewInvoicesToolStripMenuItem
            // 
            this.enterNewInvoicesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.OpenEnterMenuItem,
            this.SaveInvoiceMenuItem});
            this.enterNewInvoicesToolStripMenuItem.Name = "enterNewInvoicesToolStripMenuItem";
            this.enterNewInvoicesToolStripMenuItem.Size = new System.Drawing.Size(145, 24);
            this.enterNewInvoicesToolStripMenuItem.Text = "Enter new invoices";
            // 
            // OpenEnterMenuItem
            // 
            this.OpenEnterMenuItem.Name = "OpenEnterMenuItem";
            this.OpenEnterMenuItem.Size = new System.Drawing.Size(228, 26);
            this.OpenEnterMenuItem.Text = "Open an existing file";
            this.OpenEnterMenuItem.Click += new System.EventHandler(this.OpenEnterMenuItem_Click);
            // 
            // SaveInvoiceMenuItem
            // 
            this.SaveInvoiceMenuItem.Name = "SaveInvoiceMenuItem";
            this.SaveInvoiceMenuItem.Size = new System.Drawing.Size(228, 26);
            this.SaveInvoiceMenuItem.Text = "Save invoices";
            this.SaveInvoiceMenuItem.Click += new System.EventHandler(this.SaveInvoiceMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.CloseFormMenuItem});
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(47, 24);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // CloseFormMenuItem
            // 
            this.CloseFormMenuItem.Name = "CloseFormMenuItem";
            this.CloseFormMenuItem.Size = new System.Drawing.Size(164, 26);
            this.CloseFormMenuItem.Text = "Close form";
            this.CloseFormMenuItem.Click += new System.EventHandler(this.CloseFormMenuItem_Click);
            // 
            // OpenInvoiceFileDialog
            // 
            this.OpenInvoiceFileDialog.FileName = "openFileDialog1";
            // 
            // InvoiceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 480);
            this.Controls.Add(this.InsertButton);
            this.Controls.Add(this.NextButton);
            this.Controls.Add(this.AmountBox);
            this.Controls.Add(this.NameBox);
            this.Controls.Add(this.InvoiceNum);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "InvoiceForm";
            this.Text = "Invoice From";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox InvoiceNum;
        private System.Windows.Forms.TextBox NameBox;
        private System.Windows.Forms.TextBox AmountBox;
        private System.Windows.Forms.Button NextButton;
        private System.Windows.Forms.Button InsertButton;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewExistingInvoicesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenViewMenuItem;
        private System.Windows.Forms.ToolStripMenuItem FinishViewMenuItem;
        private System.Windows.Forms.ToolStripMenuItem enterNewInvoicesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem OpenEnterMenuItem;
        private System.Windows.Forms.ToolStripMenuItem SaveInvoiceMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem CloseFormMenuItem;
        private System.Windows.Forms.OpenFileDialog OpenInvoiceFileDialog;
        private System.Windows.Forms.SaveFileDialog SaveInvoiceFileDialog;
    }
}

