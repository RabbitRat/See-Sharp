﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;   

namespace InvoiceRecords
{
    public partial class InvoiceForm : Form
    {
        //create objects 
        StreamWriter invoiceWriter; //creating stream writer

        StreamReader invoiceReader; //need to add extend namespace system.IO
        string invoiceFile;  //save invoice.txt file
        const char DELIM = ','; //delimiter to separate different fields. 

        public InvoiceForm()
        {
            InitializeComponent();
        }

        private void InvoiceNum_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void OpenViewMenuItem_Click(object sender, EventArgs e)
        {
            //create StreamReader by using create objects at beginning, create 3 things 
            string recordIn; //one record. read a whole row at a time, read one row as a big string and store it in recordIn and then separate them into 3 parts than store in each box
            string[] fields;//create list of three string. array of string. to hop nhiu string. [invoicebox, namebox, amountbox]

            //open file dialog, (after that we actually open it, then read each row, then separate, then store)
            OpenInvoiceFileDialog.ShowDialog();  //open file explorer

            invoiceFile = OpenInvoiceFileDialog.FileName;   //this porperty contains the file , we will save it into infoiceFile variable which is defined at beginning

            //open invoicefile and create connection with that file by using stream reader
            invoiceReader = File.OpenText(invoiceFile);

            //read the first record
            recordIn = invoiceReader.ReadLine(); //what we read will be a string, we then save it into variable recordIn

            //divide into three string [invoicebox, namebox, amountbox], then result will be save into array fields  REMEMBER: fields start with [0]
            fields = recordIn.Split(DELIM);  //split by using comma or DELIM

            //we then store each field into different namebox
            InvoiceNum.Text = fields[0];
            NameBox.Text = fields[1];
            AmountBox.Text = fields[2];



        }

        private void NextButton_Click(object sender, EventArgs e)
        {
            string recordIn; //represent one row
            string[] fields;

            //Read file (=read the first record)
            recordIn = invoiceReader.ReadLine();

            //when we read the end of text, string is null
            if (recordIn != null) //not empty
            {
                //divided into 3 parts
                fields = recordIn.Split(DELIM);

                //we then store each field into different namebox
                InvoiceNum.Text = fields[0];
                NameBox.Text = fields[1];
                AmountBox.Text = fields[2];

            }
            else
            {
                //display message and close program
                
            }
                


        }

        private void FinishViewMenuItem_Click(object sender, EventArgs e)
        {
            //after view invoice.text, we want to close 
            invoiceReader.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void CloseFormMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void OpenEnterMenuItem_Click(object sender, EventArgs e)
        {
            //bring open invoice dialog
            OpenInvoiceFileDialog.ShowDialog();

            //choose file and store in invoiceFile
            invoiceFile = OpenInvoiceFileDialog.FileName;

            invoiceWriter = File.AppendText(invoiceFile);

            //clear first then input new data
            InvoiceNum.Clear();
            NameBox.Clear();
            AmountBox.Clear();

            //make sure they are enabled to input data
            InvoiceNum.Enabled = true;
            NameBox.Enabled = true;
            AmountBox.Enabled = true;

        }

        private void InsertButton_Click(object sender, EventArgs e)
        {
            //checking valid input
            double amount;
            if (double.TryParse(AmountBox.Text, out amount) == false)
            {
                AmountBox.Text = "Please enter a number";
                return;
            }
            else
            {

                //when click, record is saved to waiting room
                invoiceWriter.WriteLine(InvoiceNum.Text + DELIM + NameBox.Text + DELIM + AmountBox.Text);

                //then we want to clear all contents
                InvoiceNum.Clear();
                NameBox.Clear();
                AmountBox.Clear();
            }
        }

        private void SaveInvoiceMenuItem_Click(object sender, EventArgs e)
        {
            //save new record into file
            invoiceWriter.Close(); //close stream writer
        }
    }
}
