﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FineForOverdueBooks
{
    class Program
    {
        static void Main(string[] args)
        {
            int numBook, numDay;
            string inputString;
            
            Console.Write("How many books are overdue: ");
            inputString = Console.ReadLine();
            while (int.TryParse(inputString, out numBook) == false || (Convert.ToInt32(inputString) < 0))
            {
                Console.Write("Input must be a positive integer." + "\n" + "\nHow many books are overdue: ");
                inputString = Console.ReadLine();
            }



            Console.Write("How many days are overdue: ");
            inputString = Console.ReadLine();
            while (int.TryParse(inputString, out numDay) == false || (Convert.ToInt32(inputString) < 0))
            {
                Console.Write("Input must be a positive integer." + "\n" + "\nHow many days are overdue: ");
                inputString = Console.ReadLine();
            }


            Console.WriteLine("Your overdue fine is {0}", OverDueFine(numBook, numDay).ToString("C"));
            Console.ReadKey();

        }

        private static double OverDueFine (int Book, int Day)
        {
            const double FirstSevenDay = 0.1;
            const double AdditionalDay = 0.2;
            double fine = 0;

            if (Day <= 7)
            {
                fine = FirstSevenDay * Book * Day;
            }

            else if (Day > 7)
            {
                fine = FirstSevenDay * Book * 7 + AdditionalDay * Book * (Day - 7); 
            }

            return fine;

        }

    }
}
