﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week_2_Excercise
{
    class Program
    {
        static void Main(string[] args)
        {
            //Declare variables
            string input;
            double item_Price, tax, total;

            const double SALES_TAX = 0.06;
            
            //Promt the user for an item's price
            Console.Write("Enter the price of item >> ");
            input = Console.ReadLine();

            //Convert input into double data type
            item_Price = double.Parse(input);

            //Calculates a 6 percent sales tax
            tax = item_Price * SALES_TAX;

            //total price
            total = tax + item_Price;

            //Print out the answer
            Console.WriteLine();
            Console.WriteLine("For the item priced at {0:C}, the tax is {1:C} and the total will be {2:C}.", item_Price, tax, total);

            Console.ReadKey();
        }
    }
}
